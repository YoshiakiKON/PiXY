# Changelog

All notable changes to this project will be documented in this file.

## [1.1.1] - 2026-01-08
- Performance optimization: replaced Python loop with cv2.dilate for fast marker propagation in neck separation
- 10-100x speedup in neck separation calculation

## [1.1.2] - 2026-01-13
- Fix: wheel zoom anchor and center drift on Image/Stage views (align top-left mapping)
- UI: moved Coordinate/Rotate/Flip controls to second header row; Stage status shows Magnification/Rotation/Shift X/Shift Y/Pitch/Roll
- Fix: Magnification displayed in proc (u,v) units to match on-screen conversion

## [1.1.3] - 2026-01-13
- Release: bump version to 1.1.3, packaging rebuild and minor fixes

## [1.1.4] - 2026-01-14
- Fix: Make Image `u,v` display use full-image coordinates (avoid proc/full confusion)
- Fix: Ensure rotation/transformed calls use Qt.TransformationMode and remove stale log confusion
- Dev: Improve INFO/ERROR logging so click/align events appear when DEBUG is off

## [1.1] - 2026-01-08
- Neck separation refinement: avoid double-counting areas when splitting components
- Improved area histogram accuracy: only split areas counted post-split
- Boundary contours drawn per split component with min/max filtering applied

## [0.1.0] - 2025-10-15
- Initial codebase prepared for JOSS submission

## [1.0.1] - 2026-01-01
- UI polish: renamed labels, fixed frozen headers, improved button layout
- Fixed cumulative button width bug and clipboard feedback
- Export now prompts save location; posterization column added
- Boundary rendering adjusted for visual parity at trim_px==0
- Misc. table/column width and header alignment tweaks
